This package contains these files:

A PL model
 theops.maude
 components.maude
 rules.maude
 qq.maude

Files needed to start PLA
  load-pla.maude
  input.txt
  startup.txt
  predef-dishes.lsp

A small amount of documentation
  erk2-pnet.pdf
  syntax-summary.txt
  annotated-rules.txt
  qq.desc
 
The biology part of a Pathway Logic is made up of four files.  The first file
(theops.maude) contains all the equations that describe the operations that
are used in PL.  The second file (components.maude) declares the components
(proteins, chemicals, DNA, stimuli, etc) used in the model.  All the rules
live in rules.maude.  Several starting states are in qq.maude.

annotated-rules.txt contains a selection of
the rules in  rules.maude  annotated with explanations of
what the rules mean to a biologist.  The file syntax-summary.txt
gives an informal overview of the Pathway Logic syntax.

erk2-pnet.pdf a PetriNet picture of the annotated rules.

The first three rules (280,876,14) are the basic Raf-Mek-Erk pathway.
The other rules are some of the rules that set up the state required for the
Raf-Mek-Erk to fire.  The starting state contains activated Ras 
([Ras - GTP]) so there are no rules on how Ras gets activated.

This file makes a lot more sense if you view it using a fixed width font
like "courier".

(*) qq.maude

A starting state is written as an equation defineing a constant of sort Dish
naming that state.  In qq.maude several such constants are defined
(see qq.desc for a brief explanation).  In the dish named "TwoWaysToActRac"
the cell type is Fibroblast.  There are epidermal growth factor (Egf) and
fibronectin (FN) located outside the cell.  The cell has only two receptors:
the Egf receptor (EgfR) and the integrin alpha-5 beta-1 receptor (Ia5Ib1). 
On the inside of the cell are the components used in pathway activating
Rac1.  All of the components are in a state consistent with a quiescent cell.
The dish "ThreeWaysToActRac" is a modification of "TwoWaysToActRac"
by declaring "Cdc42" to be initially activated.  (This is needed to
find the third way to activation.)

Components are contained in compartments. The compartments used are: 

CLo - the outside of the cell membrane
CLm - the cell membrane
CLi - the inside of the cell membrane
CLc - the cytosol

There are lots more compartments used throughout the model - their symbols
can be found in theops.maude.

(*) components.maude
The names used for components are the curators preference.  
The official names of the proteins used are listed as comments.

