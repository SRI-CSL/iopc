04Dec01 

This directory contains the Pathway Logic Assistant version 1.
Uses new cleaned up IMaude.

Currently it is invoked by loading ipla.maude from a load file in a model
directory.  Loading ipla-bnet.maude also gives acess to the bionet viewer if
you have it installed.

IPLA can be put anywhere that is convenient and accessible.  
Once you choose a place, edit the final line in ipla.maude
to load PlaLib.lsp from the location of IPLA.

Then you need to edit your model load files to point to
load-ipla in IPLA
