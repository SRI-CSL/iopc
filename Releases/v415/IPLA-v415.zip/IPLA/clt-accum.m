fmod ACCUM is
  inc PETRI-SHARED .
  inc PATHWAY-PRINTING .
*** inc MY-META . 

var ?res : Result4Tuple? . 
var res : Result4Tuple . 

*** use this instead.
op pnGetSoup : Term -> Term .
eq pnGetSoup('PD[T:Term]) = T:Term .
  

*** Starting from an initial state, fire all rules collecting
*** things in the dish until there is no more to be collected.

*** Allows return value from accumRule for non-match.

op accum : Qid Term -> Term .
op accumIfChanged : Qid Term Term -> Term .
op accumRuleSet : Qid RuleSet Term -> Term .
op accumRule : Module Rule Term Nat -> Term .

*** top-level function.  Returns a dish with a superset of
*** everything that can be added by applying rules in m.
eq accum(m:Qid,DT:Term) =
  accumIfChanged(m:Qid, DT:Term, 
		 accumRuleSet(m:Qid, upRls(m:Qid,true),DT:Term)) .

*** iterate accumRuleSet until it converges
eq accumIfChanged(m:Qid, oDT:Term, nDT:Term) =
  if (getTerm(metaReduce([m:Qid],'_==_[oDT:Term,nDT:Term])) == 'true.Bool)
  then nDT:Term
  else accumIfChanged(m:Qid, nDT:Term, 
		accumRuleSet(m:Qid, upRls(m:Qid,true), nDT:Term))
  fi .

*** makes one pass over ruleset
eq accumRuleSet(m:Qid, none, DT:Term) = DT:Term .
eq accumRuleSet(m:Qid, R:Rule RS:RuleSet, DT:Term) = 
     accumRuleSet(m:Qid, RS:RuleSet, 
                  accumRule([m:Qid], R:Rule, DT:Term, 0)) .


*** apply one rule and accumulate all results in a dish.
ceq accumRule(M:Module, R:Rule, DT:Term, n:Nat) = 
    if (?res :: Result4Tuple)
    then 
      *** found a least one match 
      accumRule(M:Module, R:Rule, 
		metaDCollect(getTerm(?res), DT:Term),
	        (s n:Nat))
    else DT:Term
    fi
  if ?res :=  metaXapply(M:Module, DT:Term, getRuleId(R:Rule),
  					  none, 0, unbounded, n:Nat) .


*** apply dcollect at the meta level to two Dish terms
*** clt removed module argument
op metaDCollect : Term Term -> Term .

eq metaDCollect(DT1:Term,DT2:Term) =
   getTerm(metaReduce(['COLLECT], 'dcollect[DT1:Term,DT2:Term])) .


****************  itemization *************************

*** From a rule and the "moad" (mother of all dishes), construct
*** a Petri net transition.
***   metaXapply the rule to the moad.
***   Get context, substitution, and rule rhs, lhs
***   convert context to Loc
***   convert rhs, lhs to occs
***  make PNTrans

*** Returns a list of terms, each of which represents a petri net transition.
op Rule2Transitions : Module Term Rule Nat -> Terms .
op Rule2Transitions1 : Module Rule Result4Tuple Nat -> Terms .

ceq Rule2Transitions(M:Module, moad:Term, R:Rule, n:Nat) =
    if (?res :: Result4Tuple)
    then  *** found a match 
        ( Rule2Transitions1(M:Module,R:Rule,?res, n:Nat) ,
        Rule2Transitions(M:Module, moad:Term, R:Rule, s n:Nat) )
    else
      mtTermList
    fi 
 if ?res := metaXapply(M:Module, moad:Term, getRuleId(R:Rule),
  	              none, 0, unbounded, n:Nat) .


ceq Rule2Transitions1(M:Module, R:Rule, res, n:Nat) =
      getTerm(metaReduce(M:Module, 
              'PNTrans[mkPNRid(getRuleId(R:Rule),n:Nat),
                       iOccsT:Term, oOccsT:Term]))
  if
      cxt:Context := getContext(res) 
      /\ sb:Substitution := getSubstitution(res) 
      /\  iOccsT:Term :=
            dishT2OccsT(M:Module,getLhs(R:Rule),cxt:Context,sb:Substitution)
      /\  oOccsT:Term :=
            dishT2OccsT(M:Module,getRhs(R:Rule),cxt:Context,sb:Substitution)
     .

  op mkPNRid : Qid Nat -> Constant .
  eq mkPNRid(rid:Qid,0) = qid("'" + string(rid:Qid) + ".Qid" ) .
  eq mkPNRid(rid:Qid,n:NzNat) =
      qid("'" + string(rid:Qid) + PNRidSuffix + string(n:NzNat,10) + ".Qid" ) .

*** Returns a list of terms, each of which represents a petri net transition.
op pnconv : Qid Term -> Terms .

eq pnconv(m:Qid, moad:Term) =
  getPN([m:Qid], moad:Term, upRls(m:Qid, true)) .

op getPN : Module Term RuleSet -> Terms .

eq getPN(M:Module, moad:Term, none) = mtTermList .

eq getPN(M:Module, moad:Term, R:Rule RS:RuleSet) = 
  Rule2Transitions(M:Module, moad:Term, R:Rule, 0),
  getPN(M:Module, moad:Term, RS:RuleSet) .


*** Net output functions

  op qq : -> Module .
****  eq qq = ['QQQ] .
  eq qq =  (mod 'QQQ is including 'QQQ .
                sorts none . none none none none none endm) .

op printPNTrans : Terms -> String .
op printPNTrans1 : Term -> String .

eq printPNTrans(mtTermList) = "" .

eq printPNTrans(pnt:Term) = printPNTrans1(pnt:Term) .

eq printPNTrans((pnt:Term, pntl:TermList))
     = printPNTrans1(pnt:Term) + printPNTrans(pntl:TermList) .

*** clt fix
****HACK  M:Module fixed to be ['QQQ]
*** eliminating dill places in favor of occs

eq printPNTrans1('PNTrans [ idt:Term, ipt:Term, opt:Term ]) =
   "\n-------------------------\n" +
   "transition=" + printRidTAll(idt:Term) + "\n\n" +
****  ( if hasSort(qq,ipt:Term,'Occs)
***   then
    printOPlaces("input=", qq,occsT2tl(qq,ipt:Term)) + "\n\n" +
       printOPlaces("output=",qq,occsT2tl(qq,opt:Term)) + "\n\n" 
***   else 
***     printPlaces("input=", ipt:Term) + "\n\n" +
***     printPlaces("output=", opt:Term) + "\n\n" 
****   fi )
 .


 op printOPlaces : String Module Terms -> String .
 eq printOPlaces(s:String,M:Module,mtTermList) = "" .
 eq printOPlaces(s:String,M:Module,oT:Term) =
   s:String +  occ2label(M:Module,oT:Term) .
 eq printOPlaces(s:String,M:Module,(oT:Term, oTL:TermList)) =
    s:String + occ2label(M:Module,oT:Term) + "\n"
    + printOPlaces(s:String,M:Module,oTL:TermList) .

***(
op printPlaces : String TermList -> String .

eq printPlaces(s:String, '__[ ptl:TermList ]) = 
  printPlaces(s:String, ptl:TermList) .

eq printPlaces(s:String, (pt:Term , ptl:TermList)) =
  printPlaces(s:String, pt:Term) + "\n" + printPlaces(s:String, ptl:TermList) .

eq printPlaces(s:String, 'place [ lt:Term , tt:Term ] ) =
 s:String + printThing(qq,tt:Term) + printLocation(lt:Term) .


op printLocation : Term -> String .

eq printLocation('outside.Location) = "out" .
eq printLocation('membrane [ 'CM.MemType ]) = "CM" .
eq printLocation('interior [ 'CM.MemType ]) = "cyto" .
eq printLocation('membrane [ 'NM.MemType ]) = "NM" .
eq printLocation('interior[ 'NM.MemType ]) = "nuc" .

)
*** top level

*** Initial marking
op printState : Term -> String .

*** useable initial markint
op printStateX : Term Term -> String .

ceq printStateX(dt:Term,trl:Term) =
    printOPlaces("initial=", qq, occsT2tl(qq,uoccsT:Term))
if  res?:ResultPair? :=  metaReduce(qq,'onlyUsedD[dt:Term, trl:Term])
/\  uoccsT:Term :=  if res?:ResultPair? :: ResultPair
                    then getTerm(res?:ResultPair?)
                    else 'none.Occs fi .

*** occsT:Term := dishT2OccsT(qq,dt:Term,'nil.Loc,none) 
*** /\    res?:ResultPair? :=  metaReduce(qq,'onlyUsed[occsT:Term, trl:Term])
***                    else occsT:Term fi .
   
eq printState(dt:Term) =
    printOPlaces("initial=", qq,
                  occsT2tl(qq,dishT2OccsT(qq,dt:Term,'nil.Loc,none)))   .

op printNet : Term -> String .

*** idt is initial dish.
eq printNet(idt:Term) = 
  printState(idt:Term) + 
   printPNTrans(pnconv(getName(qq), accum(getName(qq), idt:Term))) .

op printPNet : Term -> String .
op printPNetX : Term -> String .
op printPsubNetX : Term -> String .

eq printPNet('PNet[dish:Term,'__[pntrans:TermList]]) =
     printState(dish:Term) + printPNTrans(pntrans:TermList) .

eq printPNetX('PNet[dish:Term,'__[pntrans:TermList]]) =
  printStateX(dish:Term,'__[pntrans:TermList]) + printPNTrans(pntrans:TermList) .


eq printPNetX('PNet[dish:Term,pntrans:Term]) =
  printStateX(dish:Term,pntrans:Term) + printPNTrans(pntrans:Term) .


eq printPNet('PNet[dish:Term,'nil:PNTransList]) =   printState(dish:Term) .

eq printPNetX('PNet[dish:Term,'nil:PNTransList]) =   printState(dish:Term) .


eq printPNet(notapnet:Term) = "" [ owise ] .

eq printPNetX(notapnet:Term) = "" [ owise ] .

eq printPsubNetX('petriSubnet['__[pntrans:TermList],
                            ioccsT:Term,goccsT:Term,aoccsT:Term,ooccsT:Term]) =
  printOStateX(ioccsT:Term,'__[pntrans:TermList])
  + printPNTrans(pntrans:TermList) .

eq printPsubNetX('petriSubnet[pntrans:Term,
                            ioccsT:Term,goccsT:Term,aoccsT:Term,ooccsT:Term]) =
  printOStateX(ioccsT:Term,pntrans:Term)
  + printPNTrans(pntrans:Term) .

 eq printPsubNetX('petriSubnet['nil.PNTransList,
                            ioccsT:Term,goccsT:Term,aoccsT:Term,ooccsT:Term]) =
  printOStateX(ioccsT:Term,'nil.PNTransList) .

eq printPsubNetX(notapnet:Term) = "" [ owise ] .


op printOStateX : Term Term -> String .

ceq printOStateX(occsT:Term,trl:Term) =
    printOPlaces("initial=", qq, occsT2tl(qq,uoccsT:Term))
if  res?:ResultPair? :=  metaReduce(qq,'onlyUsed[occsT:Term, trl:Term])
/\  uoccsT:Term :=  if res?:ResultPair? :: ResultPair
                    then getTerm(res?:ResultPair?)
                    else 'none.Occs fi .


endfm

*** end DILL







