***load cseq2petrig.m 
*** converting path computation sequence to petri dgraph
*** the graph id in this case is the experiment identifier

fmod CSEQ2PETRIG is
  inc PETRI-SHARED .
*** inc MY-META .
  inc PATHWAY-PRINTING .
  inc PATHWAY-COLORS .
  inc DGRAPH-SHARED .
  

  op cseq2petrig : Module String NoteList CSeq -> DGraph .


*** cseq2dgr1 processes steps one at a time -- needs the step result
*** which is either the source state of the next step or the final state
  op cseq2dgr1 : Module String NoteList StepList Term Nodes EdgeList 
                  -> DGraph .

***                      id              rid  in  bidir out  rest     final
  op cseq2dgr2 : Module String NoteList Qid Term Term Term  StepList Term 
                 Nodes EdgeList   -> DGraph .


  op isODish : Term -> Bool .
  eq isODish('PDO[occsT:Term]) = true .
  eq isODish(t:Term) = false [owise] .

 **** remove steps that apply same rule
  op hasStep : StepList Qid Substitution -> Bool .
  eq hasStep((sl0:StepList step(t:Term, rid:Qid, sb:Substitution) sl1:StepList),
             rid:Qid, sb:Substitution) = true .
  eq hasStep(sl:StepList,  rid:Qid, sb:Substitution) = false [owise] .
   
  op pruneStepList : StepList StepList -> StepList . 
  eq pruneStepList(nil,steps:StepList) = steps:StepList .
  eq pruneStepList( (step(srcT:Term, rid:Qid, sb:Substitution)  sl:StepList),
                    steps:StepList) =
         ( if hasStep(steps:StepList, rid:Qid, sb:Substitution)
          then pruneStepList(sl:StepList, steps:StepList) 
          else pruneStepList(sl:StepList,
             ( steps:StepList step(srcT:Term, rid:Qid, sb:Substitution)) ) fi) .


  eq cseq2petrig(M:Module, id:String, ntl:NoteList,
                 cseq(steps:StepList, final:Term)) =
     cseq2dgr1(M:Module, id:String,  ntl:NoteList, 
               (if isODish(final:Term)
                then pruneStepList(steps:StepList,nil)
                else steps:StepList fi),
                final:Term, {nil,0}, nil) .

*** no more steps
  eq cseq2dgr1(M:Module, id:String, ntl:NoteList, nil, final:Term, 
              {ndl:NodeList,n:Nat},edl:EdgeList)
     =  dgraph(id:String, ntl:NoteList,ndl:NodeList,edl:EdgeList) .

****!!!! HACK
**** PetriMod case -- module has the rules, dishes are PDO(occs)
  ceq cseq2dgr1(M:Module,id:String,  ntl:NoteList,
              (step('PDO[occsT:Term], rid:Qid, sb:Substitution)  sl:StepList), 
              final:Term,
              nds:Nodes,edl:EdgeList)
     = 
   cseq2dgr2(M:Module, id:String, ntl:NoteList, rid:Qid,
             iOccs:Term, bOccs:Term, oOccs:Term,
             sl:StepList, final:Term, 
             nds:Nodes,edl:EdgeList) 
   if tgt:Term := getTgtTerm(sl:StepList, final:Term) 
   /\  rl:Rule := getRule(getRls(M:Module),rid:Qid) 
   /\ sOccs:Term := (if rl:Rule :: Rule then getLhs(rl:Rule) else 'none.Occs fi)
   /\ tOccs:Term := (if rl:Rule :: Rule then getRhs(rl:Rule) else 'none.Occs fi)
   /\ iOccs:Term :=
        getTerm(metaReduce(M:Module,'Odiff[sOccs:Term,tOccs:Term]))
    /\ oOccs:Term :=
        getTerm(metaReduce(M:Module,'Odiff[tOccs:Term,sOccs:Term]))
    /\ bOccs:Term :=
        getTerm(metaReduce(M:Module,'Osame[sOccs:Term,tOccs:Term]))  .

  ceq cseq2dgr1(M:Module,id:String,  ntl:NoteList,
              (step(src:Term, rid:Qid, sb:Substitution)  sl:StepList), 
              final:Term,
              nds:Nodes,edl:EdgeList)
     = 
   cseq2dgr2(M:Module, id:String, ntl:NoteList, rid:Qid,
             iOccs:Term, bOccs:Term, oOccs:Term,
             sl:StepList, final:Term, 
             nds:Nodes,edl:EdgeList) 
   if tgt:Term := getTgtTerm(sl:StepList, final:Term) 
    /\
   cxt:Context?
        := ruleAppCxt(M:Module,rid:Qid,src:Term,tgt:Term,sb:Substitution,0) 
   /\  rl:Rule := getRule(upRls(getName(M:Module),true),rid:Qid) 
   /\ sOccs:Term :=
     (if (cxt:Context? :: Context)
      then dishT2OccsT(M:Module,getLhs(rl:Rule),cxt:Context?, sb:Substitution)
      else 'none.Occs fi)
   /\ tOccs:Term :=
     (if (cxt:Context? :: Context)
      then  dishT2OccsT(M:Module,getRhs(rl:Rule),cxt:Context?,sb:Substitution)
      else 'none.Occs fi)
    /\ iOccs:Term :=
        getTerm(metaReduce(M:Module,'Odiff[sOccs:Term,tOccs:Term]))
    /\ oOccs:Term :=
        getTerm(metaReduce(M:Module,'Odiff[tOccs:Term,sOccs:Term]))
    /\ bOccs:Term :=
        getTerm(metaReduce(M:Module,'Osame[sOccs:Term,tOccs:Term]))
[owise]   .

 ceq cseq2dgr2(M:Module, id:String, ntl:NoteList, rid:Qid,
               iOccs:Term, bOccs:Term, oOccs:Term,
              sl:StepList, final:Term, 
              nds:Nodes, edl:EdgeList) 
     =
     cseq2dgr1(M:Module, id:String,  ntl:NoteList, sl:StepList, final:Term,
              nds2:Nodes,
              edl:EdgeList  mkEdges("i",n:Nat,iids:Nats)
                            mkEdges("b",n:Nat,bids:Nats) 
                            mkEdges("o",n:Nat,oids:Nats))
    if {nds0:Nodes, iids:Nats}
         := getNodes(M:Module, 
                     nds:Nodes, emptyNatList, occsT2tl(M:Module,iOccs:Term))
       /\
       {nds1:Nodes, bids:Nats} 
          := getNodes(M:Module, 
                      nds0:Nodes,emptyNatList,occsT2tl(M:Module,bOccs:Term))
       /\
       {{ndl:NodeList, n:Nat}, oids:Nats}
          := getNodes(M:Module, 
                      nds1:Nodes,emptyNatList,occsT2tl(M:Module, oOccs:Term)) 
       /\  bnode:Node := 
            nd(n:Nat, (("label" :=  
***                       string(rid:Qid)
                        printRid(rid:Qid))
                       ("ruleid" :=  string(rid:Qid)) 
                       ("type" := "rule")
                       ("shape" := "box")))
       /\ 
         nds2:Nodes := {ndl:NodeList bnode:Node, s n:Nat} .

  op getNodes : Module Nodes Nats Terms -> getNodesResult .
  op getNode : Module Nodes Term -> getNodesResult .

  eq getNodes(M:Module, nds:Nodes, ids:Nats, mtTermList)   
       = {nds:Nodes,ids:Nats} .

  ceq getNodes(M:Module, nds:Nodes, ids:Nats, t:Term)
      =  {nds1:Nodes, (ids:Nats id:Nat)}
  if {nds1:Nodes, id:Nat} := getNode(M:Module, nds:Nodes,t:Term) .


  ceq getNodes(M:Module, nds:Nodes, ids:Nats, (t:Term, tl:TermList))
       = getNodes(M:Module, nds1:Nodes, (ids:Nats id:Nat), tl:TermList)
  if {nds1:Nodes, id:Nat} := getNode(M:Module, nds:Nodes,t:Term) .

 ceq getNode(M:Module, {ndl:NodeList,n:Nat}, t:Term)
     =  (if (res:FindResult == notFound)
         then {{(ndl:NodeList newNode(M:Module,t:Term,n:Nat)), s n:Nat}, n:Nat}
         else {{ndl:NodeList, n:Nat}, res:FindResult}
         fi)
  if res:FindResult := findNode(ndl:NodeList, "occ", t:Term, 'none.Soup) .     

  op newNode : Module Term Nat -> Node .
  ceq newNode(M:Module,t:Term,n:Nat) = 
               nd(n:Nat,(("label" := occ2labelx(M:Module,t:Term) )
                         ("chattylabel" := occ2label(M:Module,t:Term) )
                         ("type" := "occ")
***                         ("shape" := "ellipse")
***                         (if hasSort(M:Module,thT:Term,'Protein) 
***                          then ("color" := proteinColor)
***                          else ("color" := chemicalColor) fi)
                         ("occ" ::= t:Term)))
     if thT:Term := getTerm(metaReduce(M:Module,'occThing[t:Term])) .

  op mkEdges : String Nat  Nats -> EdgeList .
  op mkEdge : String Nat  Nat -> Edge .

  eq mkEdges(type:String, rid:Nat, emptyNatList) = nil .
  eq mkEdges(type:String, rid:Nat,id:Nat) = 
          mkEdge(type:String,rid:Nat,id:Nat) .
  eq mkEdges(type:String, rid:Nat,id:Nat ids:Nats) =
       mkEdge(type:String, rid:Nat, id:Nat)  mkEdges(type:String,rid:Nat,ids:Nats) .

  eq mkEdge(type:String, rid:Nat, id:Nat) =
      (if (type:String == "i")
       then ed(id:Nat, rid:Nat, nil)
****               (("label" := "i")  ("color" := iEdgeColor))
       else (if (type:String == "b")
       then ed(id:Nat, rid:Nat, ("type" := "bidirectional"))
****               (("label" := "b")  ("color" := bEdgeColor))
       else ed(rid:Nat, id:Nat, nil)
****               (("label" := "o") ("color" := oEdgeColor))
       fi) fi) .



  op r2dg : Module String NoteList Rule -> DGraph .
  ceq r2dg(M:Module,id:String, ntl:NoteList, r:Rule) =
       dgraph(id:String,ntl:NoteList,ndl:NodeList bnode:Node,
              mkEdges("i",n:Nat,iids:Nats)
              mkEdges("b",n:Nat,bids:Nats)
              mkEdges("o",n:Nat,oids:Nats) )
  if 
        rid:Qid := getRuleId(r:Rule)
    /\  src:Term := getLhs(r:Rule)
    /\  tgt:Term := getRhs(r:Rule)
    /\  locT:Term := 'nil.Loc
    /\   sb:Substitution := none
    /\ sOccs:Term :=  dishT2OccsT(M:Module,src:Term,locT:Term,sb:Substitution)
    /\ tOccs:Term :=  dishT2OccsT(M:Module,tgt:Term,locT:Term,sb:Substitution)
    /\ iOccs:Term := 
        getTerm(metaReduce(M:Module,'Odiff[sOccs:Term,tOccs:Term]))
    /\ oOccs:Term :=
        getTerm(metaReduce(M:Module,'Odiff[tOccs:Term,sOccs:Term]))
    /\ bOccs:Term :=
        getTerm(metaReduce(M:Module,'Osame[sOccs:Term,tOccs:Term]))
    /\ {nds0:Nodes, iids:Nats}
         := getNodes(M:Module, 
                    {nil,0}, emptyNatList, occsT2tl(M:Module,iOccs:Term))
    /\ {nds1:Nodes, bids:Nats} 
          := getNodes(M:Module, 
                      nds0:Nodes,emptyNatList,occsT2tl(M:Module,bOccs:Term))
    /\ {{ndl:NodeList, n:Nat}, oids:Nats}
          := getNodes(M:Module, 
                      nds1:Nodes,emptyNatList,occsT2tl(M:Module, oOccs:Term))
    /\  bnode:Node := 
            nd(n:Nat, (("label" :=  string(rid:Qid)) 
                       ("ruleid" :=  string(rid:Qid)) 
                       ("type" := "rule") ("shape" := "box")))
   .

******************************************************************************
*** highlighting goal occurrences
******************************************************************************
**** looking for eq pd:Dish |= propt = true .

   op satDef : Equation Term -> Term .
   eq satDef((eq '_|=_[dishT:Term,propT:Term] = 'true.Bool [attrs:AttrSet] .), 
             propT:Term)
              = dishT:Term .
   eq satDef(e:Equation,propT:Term) = 'PD['empty.Soup] [owise] .

  op getPropPat : Module Term -> Term .
  op getPropPat : EquationSet Term -> Term .

  eq getPropPat(M:Module, propT:Term) = 
       getPropPat(upEqs(getName(M:Module),true), propT:Term) .

  eq getPropPat(none, propT:Term) = 'PD['empty.Soup] .
  ceq getPropPat(e:Equation eqns:EquationSet, propT:Term) =
      ( if patT:Term == 'PD['empty.Soup]
        then getPropPat(eqns:EquationSet, propT:Term) 
        else patT:Term 
        fi )
   if patT:Term := satDef(e:Equation,propT:Term) .

  op hilite : Module Qid DGraph -> DGraph .
  op hiliteNodes : Module Term NodeList -> NodeList .
  op hiliteNotes : Module Term NoteList -> NoteList .

  ceq hilite(M:Module,propname:Qid,
       dgraph(id:String,ntl:NoteList,ndl:NodeList, edl:EdgeList)) =
       dgraph(id:String,ntl:NoteList,
              hiliteNodes(M:Module,pOccs:Term, ndl:NodeList),
                     edl:EdgeList) 
  if 
    ppat:Term := getPropPat(M:Module,mkConst(propname:Qid,'Prop))
    /\  locT:Term := 'nil.Loc
    /\   sb:Substitution := none
    /\ pOccs:Term :=  dishT2OccsT(M:Module,ppat:Term,locT:Term,sb:Substitution)
   .

  eq hiliteNodes(M:Module, pOccs:Term, nil) = nil .
  eq hiliteNodes(M:Module, pOccs:Term, nd(nid:Nat, ntl:NoteList) ndl:NodeList) 
      =
      nd(nid:Nat,  hiliteNotes(M:Module, pOccs:Term, ntl:NoteList)) 
      hiliteNodes(M:Module, pOccs:Term, ndl:NodeList)  .

   ceq hiliteNotes(M:Module, pOccs:Term, ntl:NoteList) =
       ( if mtest:Term == 'none.Occs
         then ntl:NoteList
         else updateNotes(ntl:NoteList, "color", goalColor) 
         fi )
   if
      occT:Term := tlookup(ntl:NoteList, "occ", 'nada.Occ)
     /\
      mtest:Term :=
       ( if (occT:Term == 'nada.Occ) 
         then 'none.Occs
         else getTerm(metaReduce(M:Module, 'member[occT:Term,pOccs:Term])) fi )
    .

    op updateNotes : NoteList String String -> NoteList .
    eq updateNotes(nil, tag:String, val:String) =
        (tag:String := val:String) .
    eq updateNotes(nt:Note ntl:NoteList, tag:String, val:String) = 
       ( if (nt:Note :: ANote) 
         then (if (atag(nt:Note) == tag:String)
               then (tag:String := val:String)
               else nt:Note
               fi)
          else nt:Note fi )
        updateNotes(ntl:NoteList, tag:String, val:String) .

endfm

