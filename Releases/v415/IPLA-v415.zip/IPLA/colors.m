fmod PATHWAY-COLORS is
  inc STRING .

*****************************************************************************
*******  colors
*****************************************************************************

  ops proteinColor chemicalColor goalColor : -> String .
  ops iEdgeColor oEdgeColor bEdgeColor : -> String .
  eq proteinColor = "lightBlue" .
  eq chemicalColor = "lightCyan" .
  eq goalColor =  "yellow" .
***  eq goalColor =  "purple" .

  eq iEdgeColor = "magenta" .
  eq oEdgeColor = "green" .
  eq bEdgeColor = "blue" .

endfm