*** for new location style

mod DISH-OPS is 
    inc PROTEINOPS .
    inc STRING .

***(

Loc is Out or (celltype . locname)

< thing,loc >  is an Occ (occurrence) --
  loc identifies occurrence of thing  as supernatant or compartment in cell


delOccDish(occ,dish) removes occ from dish -- all of the things at the location
Odiff(ox1:Occs,ox2:Occs) returns the elements of ox1 that are not in ox2
   if Odiff(occs1,occs1) = none then occs1 << occs2.

Osame(ox1:Occs,ox2:Occs) returns the elements that are in both ox1 and ox2


Assume dish is PD(dsoup)
       dsoup is (thing + cell) *
       cell is [celltype | lsoup]
       lsoup is [locname | tsoup]*
       tsoup is thing*

Further more celltype is unique in dish
             locname is unique in cell
)

  sort Loc .
  op _`,_ : CellType LocName -> Loc [ctor] .
  op Out : -> Loc [ctor] .

***(
ops CLo CLm CLi CLc : -> LocName .  *** Cell - out,mem,in,cytosol
ops NUo NUm NUi NUc : -> LocName .  *** Nucleus - out,mem,in,cytosol
ops MOo MOm MOi MOc : -> LocName .  *** Mitochondria Outer membrane
ops MIo MIm MIi MIc : -> LocName .  *** Mitochondria Inner membrane
ops ERo ERm ERi ERc : -> LocName .  *** EndoplasmicReticulum
ops PXo PXm PXi PXc : -> LocName .  *** PeroXisome
ops GAo GAm GAi GAc : -> LocName .  *** Golgi Apparatus
ops LEo LEm LEi LEc : -> LocName .  *** Late Endosomes
ops LYo LYm LYi LYc : -> LocName .  *** Lysosome
ops CPo CPm CPi CPc : -> LocName .  *** Clathrin Coated Pits
*** op LR : -> LocName .  *** Lipid Rafts in the CM
*** op CC : -> LocName .  *** Clathrin Coated Pits in the CM

op MuscleCell : -> CellType .
op LiverCell : -> CellType .
op Fibroblast : -> CellType .
)

  ops loc2string floc2string  : Loc -> String .
  op celltype2string : CellType -> String .
  op locname2string : LocName -> String .
  eq floc2string(Out) = "out" .
  eq floc2string((ct:CellType,ln:LocName)) = 
      celltype2string(ct:CellType) + "."  + locname2string(ln:LocName) .

  eq loc2string(Out) = "out" .
  eq loc2string((ct:CellType,ln:LocName)) = locname2string(ln:LocName) .

  eq celltype2string(MuscleCell) = "muscle" .
  eq celltype2string(LiverCell) = "liver" .
  eq celltype2string(Fibroblast) = "fibroblast" .

  eq locname2string(CLo) = "CLo" .
  eq locname2string(CLm) = "CLm" .
  eq locname2string(CLi) = "CLi" .
  eq locname2string(CLc) = "CLc" .

  eq locname2string(NUo) = "NUo" .
  eq locname2string(NUm) = "NUm" .
  eq locname2string(NUi) = "NUi" .
  eq locname2string(NUc) = "NUc" .

  eq locname2string(MOo) = "MOo" .
  eq locname2string(MOm) = "MOm" .
  eq locname2string(MOi) = "MOi" .
  eq locname2string(MOc) = "MOc" .

  eq locname2string(MIo) = "MIo" .
  eq locname2string(MIm) = "MIm" .
  eq locname2string(MIi) = "MIi" .
  eq locname2string(MIc) = "MIc" .

  eq locname2string(ERo) = "ERo" .
  eq locname2string(ERm) = "ERm" .
  eq locname2string(ERi) = "ERi" .
  eq locname2string(ERc) = "ERc" .

  eq locname2string(PXo) = "PXo" .
  eq locname2string(PXm) = "PXm" .
  eq locname2string(PXi) = "PXi" .
  eq locname2string(PXc) = "PXc" .

  eq locname2string(GAo) = "GAo" .
  eq locname2string(GAm) = "GAm" .
  eq locname2string(GAi) = "GAi" .
  eq locname2string(GAc) = "GAc" .

  eq locname2string(LEo) = "LEo" .
  eq locname2string(LEm) = "LEm" .
  eq locname2string(LEi) = "LEi" .
  eq locname2string(LEc) = "LEc" .

  eq locname2string(LYo) = "LYo" .
  eq locname2string(LYm) = "LYm" .
  eq locname2string(LYi) = "LYi" .
  eq locname2string(LYc) = "LYc" .

  eq locname2string(CPo) = "CPo" .
  eq locname2string(CPm) = "CPm" .
  eq locname2string(CPi) = "CPi" .
  eq locname2string(CPc) = "CPc" .

  eq locname2string(Sig) = "Sig" .

***  eq locname2string(LR) = "LR" .
***  eq locname2string(CC) = "CC" .

  sorts Occ Occs .
  subsort Occ < Occs .

  op <_,_> : Thing Loc -> Occ .
  op occThing : Occ -> Thing .
  op occLoc : Occ -> Loc .
  eq occThing(< th:Thing,l:Loc >) = th:Thing .
  eq occLoc(< th:Thing,l:Loc >) = l:Loc .

  op none : -> Occs .
  op __ : Occs Occs -> Occs  [assoc comm id: none] .
  
  op size : Occs -> Nat .
  eq size(none) = 0 .
  eq size(o:Occ os:Occs) = s(size(os:Occs)) .

  op dish2occs : Dish -> Occs .
  op dsoup2occs : Soup -> Occs .
  op csoup2occs : Soup CellType -> Occs .
  op lsoup2occs : Soup Loc -> Occs .

  eq dish2occs(PD(s:Soup)) = dsoup2occs(s:Soup) .

  eq dsoup2occs(empty) = none .

  eq dsoup2occs(th:Thing s:Soup) =  < th:Thing, Out > dsoup2occs(s:Soup) .
  eq dsoup2occs([ct:CellType | cs:Soup] s:Soup) = 
         csoup2occs(cs:Soup, ct:CellType) dsoup2occs(s:Soup) .
  eq dsoup2occs(s:Soup) = none [owise] .
       
  eq csoup2occs(empty, ct:CellType) = none .
  eq csoup2occs({ln:LocName | ls:Soup } cs:Soup, ct:CellType)
        = lsoup2occs(ls:Soup, (ct:CellType,ln:LocName))
          csoup2occs( cs:Soup, ct:CellType) .
       
  eq lsoup2occs(empty, l:Loc) = none .
  eq lsoup2occs(th:Thing ls:Soup, l:Loc) =
          < th:Thing, l:Loc > lsoup2occs(ls:Soup, l:Loc) .
       
  op member : Occ Occs -> Occs . *** none or occ
  eq member(o:Occ,none) = none .
  eq member(o:Occ, o1:Occ ox:Occs) = 
       if (o:Occ == o1:Occ) then o:Occ else member(o:Occ, ox:Occs) fi .

 
  op Odiff : Occs Occs -> Occs .
  eq Odiff(none, ox2:Occs)  = none .
  eq Odiff(o:Occ ox1:Occs, ox2:Occs) =
     (if (member(o:Occ, ox2:Occs) == none) then o:Occ else none fi)
     Odiff(ox1:Occs, ox2:Occs) .
    
  op Osame : Occs Occs -> Occs .
  eq Osame(none, ox2:Occs)  = none .
  eq Osame(o:Occ ox1:Occs, ox2:Occs) =
     member(o:Occ, ox2:Occs)  Osame(ox1:Occs, ox2:Occs) .

  op addOccs : Occs Occs -> Occs . *** add avoiding duplicates
  eq addOccs(accum:Occs,ooccs:Occs) = Odiff(accum:Occs,ooccs:Occs) ooccs:Occs .


*** assuming a dish contains one cell and some outside things
  op delOccDish : Occ Dish -> Dish .
  op delOccCSoup : Thing LocName Soup  -> Soup .
  op delThingSoup : Thing Soup  -> Soup .

  eq delOccDish( < th:Thing, Out >, PD(th:Thing ds:Soup))  =  PD(ds:Soup) .
  eq delOccDish( < th:Thing, (ct:CellType,ln:LocName) >,
                 PD([ct:CellType | cs:Soup] ds:Soup))  =
     PD(delOccCSoup(th:Thing,ln:LocName,cs:Soup) ds:Soup ) .
  eq delOccDish(occ:Occ, d:Dish) = d:Dish [owise] .

  eq delOccCSoup(th:Thing, ln:LocName, {ln:LocName | ls:Soup} cs:Soup) = 
       {ln:LocName | delThingSoup(th:Thing,ls:Soup)} cs:Soup . 
  eq delOccCSoup(th:Thing, ln:LocName, cs:Soup) = cs:Soup [owise] .

  eq delThingSoup(th:Thing, th:Thing ls:Soup) = ls:Soup .
  eq delThingSoup(th:Thing, ls:Soup) = ls:Soup [owise] .


endm

*** begin DILL
mod COLLECT is 
    inc PROTEINOPS .

  *** non-meta-level support for collecting interpretation.
  *** I think this can be done better using contexts, etc. 

  op member : Thing Soup -> Bool .

  eq member(x:Thing, x:Thing S:Soup) = true .
  eq member(x:Thing, S:Soup) = false [owise] .


***          from    to   
  op dcollect : Dish Dish -> Dish .
  op dscollect : Soup Soup -> Soup .
  op cscollect : Soup Soup -> Soup .
  op lscollect : Soup Soup -> Soup .

  eq dcollect(PD(s1:Soup),PD(s2:Soup)) = PD(dscollect(s1:Soup,s2:Soup)) . 

*** dish level soup
  eq dscollect(empty, S2:Soup) = S2:Soup .

  eq dscollect(x:Thing S1:Soup, S2:Soup) =
    if member(x:Thing, S2:Soup) 
    then dscollect(S1:Soup, S2:Soup) 
    else dscollect(S1:Soup, x:Thing S2:Soup) fi .

  eq dscollect(Y1:Soup [ct:CellType | cs:Soup],
               Y2:Soup [ct:CellType | cs0:Soup]) =
     dscollect(Y1:Soup,Y2:Soup) [ct:CellType | cscollect(cs:Soup,cs0:Soup)] .
  eq dscollect(Y1:Soup [ct:CellType | cs:Soup], Y2:Soup) = *** new cell
         dscollect(Y1:Soup, Y2:Soup) [ct:CellType | cs:Soup] [owise] .

*** cell level soup
  eq cscollect(empty, S2:Soup) = S2:Soup .

  eq cscollect(Y1:Soup {ln:LocName | S1:Soup}, 
               Y2:Soup {ln:LocName | S2:Soup}) =
     cscollect(Y1:Soup,Y2:Soup) {ln:LocName | lscollect(S1:Soup,S2:Soup)} .

  eq cscollect(Y1:Soup {ln:LocName | S1:Soup}, Y2:Soup) = *** new cellloc
       cscollect(Y1:Soup,Y2:Soup) {ln:LocName | S1:Soup} [owise] .

  eq lscollect(empty, S2:Soup) = S2:Soup .
  eq lscollect(th:Thing S1:Soup, S2:Soup) =
       (if member(th:Thing,S2:Soup)
        then lscollect(S1:Soup, S2:Soup) 
        else lscollect(S1:Soup, th:Thing  S2:Soup) 
        fi) .

endm

***load itemize.m

mod PETRI is
  inc DISH .
  inc QID-LIST .
  inc DISH-OPS .
  inc SIMPLE .    **** for rulenamelists
***  inc ITEMIZE .

*** op PNTrans : Qid Places Places -> PNTransition .
*** op notrans : -> PNTransition .

  sort PNTransition .
  op PNTrans : Qid Occs Occs -> PNTransition .

  sorts PetriNet PNTransList .
  subsort  PNTransition < PNTransList .


  op nil : -> PNTransList .
  op  __ : PNTransList PNTransList -> PNTransList [assoc id: nil] .
  op PNet : Dish PNTransList -> PetriNet .

  op petriNetDish : PetriNet -> Dish .
  op petriNetTrans : PetriNet -> PNTransList .

  eq petriNetDish(PNet(d:Dish,tl:PNTransList)) = d:Dish .
  eq petriNetTrans(PNet(d:Dish,tl:PNTransList)) = tl:PNTransList .

  op onlyUsed : Occs PNTransList -> Occs .
  op onlyUsedD : Dish PNTransList -> Occs .
  op Used : Occ PNTransList -> Occs .

  eq onlyUsedD(d:Dish,tl:PNTransList)
        = onlyUsed(dish2occs(d:Dish),tl:PNTransList) .

  eq onlyUsed(none,tl:PNTransList) = none .
  eq onlyUsed(occ:Occ occs:Occs,tl:PNTransList) =
      (Used(occ:Occ,tl:PNTransList) onlyUsed(occs:Occs,tl:PNTransList)) .

  eq  Used(occ:Occ,nil) = none .
  eq   Used(occ:Occ, PNTrans(rid:Qid, iOccs:Occs,oOccs:Occs) tl:PNTransList)
       = ( if (member(occ:Occ, iOccs:Occs) =/= none)
           then occ:Occ
           else Used(occ:Occ, tl:PNTransList)
           fi ) .

  op allUsed : PNTransList -> Occs .
  eq allUsed(nil) = none .
  eq allUsed(PNTrans(rid:Qid, iOccs:Occs,oOccs:Occs) tl:PNTransList)
       = addOccs(iOccs:Occs,addOccs(oOccs:Occs,allUsed(tl:PNTransList))) .
  
  op notUsedD : Dish PNTransList -> Occs .
  op notUsed : Occs PNTransList -> Occs .

  eq notUsedD(d:Dish,tl:PNTransList)
        = notUsed(dish2occs(d:Dish),tl:PNTransList) .
  eq notUsed(none,tl:PNTransList) = none .
  eq notUsed(occ:Occ occs:Occs,tl:PNTransList) =
     ((if (Used(occ:Occ,tl:PNTransList) == occ:Occ) then none else occ:Occ fi)
      notUsed(occs:Occs,tl:PNTransList)) .


  op getTrans : PNTransList RuleNameList -> PNTransList .
  eq getTrans(nil,rnl:RuleNameList) = nil .
  eq getTrans(PNTrans(rid:Qid, iOccs:Occs,oOccs:Occs) tl:PNTransList,
              rnl0:RuleNameList rid:Qid rnl:RuleNameList) = 
     ( PNTrans(rid:Qid, iOccs:Occs,oOccs:Occs) 
       getTrans(tl:PNTransList,rnl0:RuleNameList rnl:RuleNameList) ) .
  eq getTrans(PNTrans(rid:Qid, iOccs:Occs,oOccs:Occs) tl:PNTransList,
              rnl:RuleNameList) =
      getTrans(tl:PNTransList, rnl:RuleNameList) [owise] .

endm
