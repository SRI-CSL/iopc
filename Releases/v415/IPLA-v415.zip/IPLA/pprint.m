fmod PATHWAY-PRINTING is
  inc MY-META .
  inc STRING .
  inc CONVERSION .

**** printing rule ids
*** print  up to first dot in ddd, or all if no dot
  op printRid : Qid -> String .
  ceq printRid(rid:Qid) =
     ( if (res:FindResult :: Nat)
      then substr(rn:String,0,res:FindResult)
      else rn:String fi)
   if rn:String := string(rid:Qid) 
    /\
     res:FindResult := find(rn:String, ".",0) .

  op PNRidSuffix : -> String .
  eq PNRidSuffix = "#" .

**** ridT has form ''ddd.Qid  maybe ddd has no dot
*** print  up to first dot in ddd, or all if no dot
*** if PNRidSuffix occurs, then what follows is rule instance index n
*** add -n to printed id
  op printRidT : Term -> String .
  ceq printRidT(ridT:Constant) =
       prn:String + sfx:String     
  if rn:String := string(getName(ridT:Constant)) 
     /\
    res:FindResult := find(rn:String, ".", 0) 
     /\
    prn:String :=
       substr(rn:String, 1, 
              ( if res:FindResult :: Nat 
                then sd(res:FindResult,1)
                else length(rn:String) fi))
     /\
    res1:FindResult := rfind(rn:String, PNRidSuffix, length(rn:String)) 
    /\ 
    sfx:String :=
        (if res1:FindResult :: Nat
         then "-" + substr(rn:String,s res1:FindResult, length(rn:String)) 
         else "" fi) 
      .

**** print the full id (just drop the single quote)
  op printRidTAll : Term -> String .
  ceq printRidTAll(ridT:Constant) =
         substr(rn:String, 1,length(rn:String)) 
  if rn:String := string(getName(ridT:Constant)) .


*** turning occs into strings
*** module must include DISH-OPS  (define Occ, Loc)


  op printOccTms : Module Terms -> String .
  eq printOccTms(M:Module,mtTermList) = "" .
  eq printOccTms(M:Module,oT:Term) =  occ2label(M:Module,oT:Term) .
  eq printOccTms(M:Module,(oT:Term,oTL:TermList)) = 
       occ2label(M:Module,oT:Term) + " " + printOccTms(M:Module,oTL:TermList) .

  op occ2label : Module Term -> String .
  ceq occ2label(M:Module, oT:Term) =
     if (hasSort(M:Module,oT:Term,'Occ))
     then  printThing(M:Module,thT:Term)
            + "-" +  printLoc(M:Module, lT:Term)
     else "" fi 
   if thT:Term := getTerm(metaReduce(M:Module,'occThing[oT:Term]))
     /\
      lT:Term := getTerm(metaReduce(M:Module,'occLoc[oT:Term])) .

**** suppress printing of loc
  op occ2labelx : Module Term -> String .
  ceq occ2labelx(M:Module, oT:Term) =
     if (hasSort(M:Module,oT:Term,'Occ))
     then  printThing(M:Module,thT:Term)  
             **** + "-" + printLoc(M:Module, lT:Term)
     else "" fi 
   if thT:Term := getTerm(metaReduce(M:Module,'occThing[oT:Term]))
     /\
      lT:Term := getTerm(metaReduce(M:Module,'occLoc[oT:Term])) .

  op printLoc : Module Term -> String .

 ceq printLoc(M:Module,lT:Term) =
     ( if res:ResultPair :: ResultPair
       then downTerm(getTerm(res:ResultPair), "?")
       else "?" 
       fi )
   if res:ResultPair :=  metaReduce(M:Module,'loc2string[lT:Term]) .

  op isModified : Module Term -> Bool .
  eq isModified(M:Module,'`[_-_`][p:Term,ms:Term]) = true .
  eq isModified(M:Module,t:Term) = false [owise] .

  ops printThing printComplex printModified printModSet
       : Module Term -> String .
  op printModList : Module TermList -> String .

  eq printThing(M:Module,th:Term) = 
    (if th:Term :: Constant then string(getName(th:Term))
    else (if th:Term :: Variable then "?" + string(getType(th:Term)) 
    else (if hasSort(M:Module,th:Term, 'Complex) 
         then printComplex(M:Module,th:Term)
    else **** its a modified thing
         (if isModified(M:Module,th:Term)
         then printModified(M:Module,th:Term)
    else "???" fi) fi) fi) fi) .

  eq printComplex(M:Module,'_:_[th0:Term, th1:Term]) =
   "(" + printThing(M:Module,th0:Term) + ":" 
    + printThing(M:Module,th1:Term) + ")" .

  eq printModified(M:Module,'`[_-_`][p:Term,ms:Term]) = 
      "" + printThing(M:Module,p:Term) + "-" 
          + printModSet(M:Module,ms:Term) + "" .

***(
Modification is
  constant
  op[site]
site is '__[aa,n]


)

  eq  printModSet(M:Module,m:Constant) = string(getName(m:Constant)) .
  eq  printModSet(M:Module,op:Qid[tl:TermList]) =
        if (op:Qid == '__)
        then printModList(M:Module,tl:TermList) 
***        else (if (tl:TermList :: Constant)
***              then string(op:Qid) + "(" + string(getName(tl:TermList)) + ")"
***              else "" fi)
***      else printOpTerm(op:Qid, tl:TermList)
         else printSiteMod(op:Qid, tl:TermList)
          fi .

  op printSiteMod : Qid TermList -> String .
  eq printSiteMod(op:Qid, t:Term) =
      string(op:Qid) + "-" + printSite(t:Term) .

  op printSite : Term -> String .
  eq printSite(c:Constant) = string(getName(c:Constant)) .
  eq printSite('__[c:Constant,nT:Term]) =
        string(getName(c:Constant)) + printNat(nT:Term).

  op printNat : Term -> String .
  eq printNat(t:Term) = string(downTerm(t:Term,0),10) .

  op printOpTerm : Qid TermList -> String .
  op printTerm : Term -> String .
  op printTermList : TermList -> String .

  eq printOpTerm(op:Qid, t:Term) = 
       string(op:Qid) + "(" + printTerm(t:Term) + ")" .

  eq printOpTerm(op:Qid,(t:Term, tl:TermList)) = 
       string(op:Qid) + "(" + printTermList(t:Term) + "," +
                          printTermList(tl:TermList) + ")" .

  eq printTermList(t:Term) = 
        (if (t:Term :: Variable) 
         then "?" + string(getName(t:Term))
         else (if (t:Term :: Constant)
               then  string(getName(t:Term))
               else printOpTerm(getOp(t:Term),getArgs(t:Term))
               fi ) fi ) .
                
    eq printTermList((t:Term,tl:TermList)) =
        printTermList(t:Term) + "," + printTermList(tl:TermList) . 

  eq  printModList(M:Module,t:Term) = printModSet(M:Module,t:Term) .
  eq  printModList(M:Module,(t:Term, tl:TermList)) =
        printModSet(M:Module,t:Term) + " " 
        + printModList(M:Module,tl:TermList)  .

  op stringT2String : Term -> String .
  ceq stringT2String(t:Term) = 
     if (t:Term :: Constant) and getType(t:Term) == 'String
     then substr(s:String,1,sd(length(s:String),2))
     else "" fi 
   if s:String := string(getName(t:Term)) .

endfm