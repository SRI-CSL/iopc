
fmod PN2D is
  inc ACCUM .   *** printing pnet style locations FIX
  inc CSEQ2PETRIG .


*** Assumes module is qq = ['QQQ]  FIX

*** Terms is list of pnet transitions (meta represented)
  op pn2dg : Module String NoteList Terms -> DGraph .  

*** pn2dg1 processes transitions one at a time 
  op pn2dg1 : Module String NoteList Terms Nodes EdgeList -> DGraph .
  op pn2dg2 : Module String NoteList Term Terms Nodes EdgeList -> DGraph .
  op pn2dg2o : Module String NoteList Qid Term Term Terms Nodes EdgeList
                   -> DGraph .
***  op pn2dg2p : Module String NoteList Qid Term Term Terms Nodes EdgeList
***                   -> DGraph .

  op addEdges : EdgeList Nats Nat Nats -> EdgeList .
  op addEdges1 : EdgeList Nats Nat -> EdgeList .
  op addEdges2 : EdgeList Nat Nats -> EdgeList .


***(
  op getOccNodes : Module Nodes  Nats Term -> getNodesResult .
  op getOccNodes1 : Module Nodes  Nats Terms -> getNodesResult .
  op getOccNodes2 : Module Nodes  Nats Term Terms -> getNodesResult .
  op getOccNode : Module Nodes Term -> getNodesResult .
)
  eq pn2dg(M:Module, id:String, ntl:NoteList, tms:Terms) =
     pn2dg1(M:Module, id:String, ntl:NoteList, tms:Terms, {nil,0}, nil) .

  eq pn2dg1(M:Module, id:String,  ntl:NoteList, mtTermList, 
            {ndl:NodeList,n:Nat},edl:EdgeList)
     =  dgraph(id:String,  ntl:NoteList, ndl:NodeList,edl:EdgeList) .

  eq pn2dg1(M:Module,id:String,  ntl:NoteList,  transT:Term, 
               nds:Nodes,edl:EdgeList)
     = 
     pn2dg2(M:Module, id:String,  ntl:NoteList, transT:Term, mtTermList,
              nds:Nodes,edl:EdgeList)  .

  eq pn2dg1(M:Module,id:String, ntl:NoteList,  (transT:Term, tl:TermList),
               nds:Nodes,edl:EdgeList)
     = 
     pn2dg2(M:Module, id:String, ntl:NoteList, transT:Term, tl:TermList,
              nds:Nodes,edl:EdgeList)  .

  eq pn2dg2(M:Module, id:String,  ntl:NoteList,
             'PNTrans[ridT:Term, inP:Term, outP:Term],
             tms:Terms,
             nds:Nodes, edl:EdgeList) 
    =
        pn2dg2o(M:Module, id:String, ntl:NoteList, 
                   ridT:Term, inP:Term, outP:Term, tms:Terms,
                   nds:Nodes,edl:EdgeList)  .

  ceq pn2dg2o(M:Module, id:String,  ntl:NoteList,
             ridT:Term, inP:Term, outP:Term,
             tms:Terms,
             nds:Nodes, edl:EdgeList) 
     =
     pn2dg1(M:Module, id:String,  ntl:NoteList, tms:Terms,
              nds2:Nodes,
              edl:EdgeList  mkEdges("i",n:Nat,iids:Nats)
                            mkEdges("b",n:Nat,bids:Nats) 
                            mkEdges("o",n:Nat,oids:Nats))
    if
      iOccs:Term :=
        getTerm(metaReduce(M:Module,'Odiff[inP:Term,outP:Term]))
    /\ oOccs:Term :=
        getTerm(metaReduce(M:Module,'Odiff[outP:Term,inP:Term]))
    /\ bOccs:Term :=
        getTerm(metaReduce(M:Module,'Osame[inP:Term,outP:Term]))
    /\ {nds0:Nodes, iids:Nats}
         := getNodes(M:Module, 
                     nds:Nodes, emptyNatList, occsT2tl(M:Module,iOccs:Term))
    /\ {nds1:Nodes, bids:Nats} 
          := getNodes(M:Module, 
                      nds0:Nodes,emptyNatList,occsT2tl(M:Module,bOccs:Term))
    /\ {{ndl:NodeList, n:Nat}, oids:Nats}
          := getNodes(M:Module, 
                      nds1:Nodes,emptyNatList,occsT2tl(M:Module, oOccs:Term)) 
    /\  bnode:Node := 
            nd(n:Nat, (("label" :=  printRidT(ridT:Term))
                       ( "type" := "rule")                       
                       ( "ruleid" := string(getRid(ridT:Term)))          
                       ( "preids" := nats2string(iids:Nats bids:Nats))         
                       ( "postids" := nats2string(oids:Nats bids:Nats))    
***                       ("shape" := "box")
                       ))
    /\ 
       nds2:Nodes := {ndl:NodeList bnode:Node, s n:Nat} .

******************************************************************************

***(
  op getBoxNode : Nodes Term -> getNodesResult .
   eq getBoxNode({ndl:NodeList, n:Nat}, ridT:Term)  =
        {{(ndl:NodeList
           nd(n:Nat, (("label" := printRidT(ridT:Term)) ("shape" := "box")
                       ("type" := "rule")))),
           _+_(1,n:Nat)}, n:Nat} .
)
  eq addEdges(edl:EdgeList,  inPids:Nats, boxid:Nat, outPids:Nats) =
      addEdges2(addEdges1(edl:EdgeList,  inPids:Nats, boxid:Nat),
                 boxid:Nat, outPids:Nats) .

  eq addEdges1(edl:EdgeList,  emptyNatList, boxid:Nat) = edl:EdgeList .

  eq addEdges1(edl:EdgeList,  pid:Nat, boxid:Nat) = 
       (edl:EdgeList ed(pid:Nat, boxid:Nat, nil ) ) .
****       (edl:EdgeList ed(pid:Nat, boxid:Nat, (("label" := "i")) ) ) .

  eq addEdges1(edl:EdgeList,  (pid:Nat pids:NatList), boxid:Nat) = 
      addEdges1((edl:EdgeList ed(pid:Nat, boxid:Nat,nil)),
****    (("label" := "i"))
                 pids:NatList, boxid:Nat ) .

  eq addEdges2(edl:EdgeList, boxid:Nat,  emptyNatList) = edl:EdgeList .

  eq addEdges2(edl:EdgeList,  boxid:Nat, pid:Nat) = 
       (edl:EdgeList ed(boxid:Nat, pid:Nat, nil) ) .
****       (edl:EdgeList ed(boxid:Nat, pid:Nat, (("label" := "o"))) ) .

  eq addEdges2(edl:EdgeList, boxid:Nat,  (pid:Nat pids:NatList)) = 
      addEdges2((edl:EdgeList ed(boxid:Nat, pid:Nat,nil)),
**** (("label" := "o"))
                 boxid:Nat,  pids:NatList) .


endfm
