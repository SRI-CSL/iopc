*** for new location style  

fmod PETRI-SHARED is
  inc MY-META .

  op occsT2tl : Module Term -> Terms .
  ceq occsT2tl(M:Module, tT:Term) =
    (if (res:ResultPair? :: ResultPair)
     then (if getType(res:ResultPair?) == 'Occ
           then getTerm(res:ResultPair?)
           else (if getType(res:ResultPair?) == 'Occs
                 then ( if (getTerm(res:ResultPair?) :: Constant or
                            getTerm(res:ResultPair?) :: Variable)
                        then mtTermList
                        else getArgs(getTerm(res:ResultPair?)) fi)
                 else mtTermList fi) fi)
     else mtTermList fi)
  if res:ResultPair? := metaReduce(M:Module,tT:Term) .

  sort Context? .
  subsort Context < Context? .
  op noCxt : -> Context? .

***(
***                          rid src  tgt                   location term
  op dishRuleAppLoc : Module Qid Term Term Substitution -> Term .

*** need to fix the not apply case
  ceq dishRuleAppLoc(M:Module, rid:Qid, src:Term, tgt:Term, sb:Substitution) =
      if (cxt:Context? :: Context)
      then  dishCxt2LocT(M:Module,cxt:Context?)
      else 'Out.Loc
      fi
  if
   cxt:Context?
        := ruleAppCxt(M:Module,rid:Qid,src:Term,tgt:Term,sb:Substitution,0) .
)

  op ruleAppCxt : Module Qid Term Term Substitution Nat -> Context? .
  var res : Result4Tuple? .
  ceq ruleAppCxt(M:Module, rlab:Qid, src:Term, tgt:Term,sb:Substitution,n:Nat)
       = if (res :: Result4Tuple) 
         then (if (getTerm(res) == tgt:Term)
               then getContext(res)
               else ruleAppCxt(M:Module, rlab:Qid, src:Term, tgt:Term, 
                               sb:Substitution, s n:Nat)
               fi)
          else noCxt
          fi
    if res := metaXapply(M:Module, src:Term, rlab:Qid, 
                        sb:Substitution, 0, unbounded, n:Nat) .


***(
 assume toplevel is a dish PD[dsoup]  as specified in NewLocDishx.m
 dishCxt is one of 
      []
      'PD(dsoupCxt)
 dsoupCxt is one of 
      []
      thCxt
      cellCxt
      '__[tms,thCxt,tms']
      '__[tms,cellCxt,tms']
 thCxt is unlikely unless we have (th0 : th1Cxt)
 cellCxt is '[_|_][ctypeT, csoupCxt]

 csoupCxt is one of
       []
       '{_|_}[locNameT, lsoupCxt]
       '__[tms,'{_|_}[locNameT, lsoupCxt],tms']
 lsoupCxt is one of
       []
       thCxt
       '__[tms,[],tms]
       '__[tms,thCxt,tms]
)

*** get around the termlist defect!!!
  op getCTLCxt : CTermList -> Context .
  eq getCTLCxt(cxt:Context) = cxt:Context .
  eq getCTLCxt((cxt:Context,tl:TermList)) = cxt:Context .
  eq getCTLCxt((tm:Term, ctl:CTermList)) = getCTLCxt(ctl:CTermList) .

  op metaOccsConc : Module Term Term -> Term .
  ceq metaOccsConc(M:Module, occsT1:Term, occsT2:Term) =
       (if res?:ResultPair :: ResultPair
        then getTerm(res?:ResultPair)
        else 'none.Occs fi)
    if res?:ResultPair := metaReduce(M:Module, '__[occsT1:Term, occsT2:Term]) .

*** can't do substituion first, want to drop the soup variables
***                    lhs/rhs loc                  occsT          
***  op dishT2OccsT : Module Term Term Substitution -> Term .
  op dishT2OccsT : Module Term Context Substitution -> Term .
  op dsoupL2OccsT : Module Term Context Substitution -> Term .
  op csoupL2OccsT : Module Term Term Context Substitution -> Term .

*** located at dsoup level find the occs
  op dsoupArgs2OccsT : Module TermList Substitution -> Term .
  op dsoupT2OccsT : Module Term  Substitution -> Term .

*** located at csoup level find the occs
***                      ctype csoup
  op csoupT2OccsT : Module Term Term Substitution -> Term .
  op csoupArgs2OccsT : Module Term TermList Substitution -> Term .
*** co-located things      loc  lsoup
  op lsoupT2OccsT : Module Term Term Substitution -> Term .
  op lsoupArgs2OccsT : Module Term TermList Substitution -> Term .


*** tT:Term better be a dish
  eq dishT2OccsT(M:Module,tT:Term,[],sb:Substitution) =
       dsoupArgs2OccsT(M:Module,getArgs(tT:Term),sb:Substitution) .
  eq dishT2OccsT(M:Module,tT:Term,'PD[dsoupCxt:Context],sb:Substitution) =
       dsoupL2OccsT(M:Module,tT:Term,dsoupCxt:Context,sb:Substitution) .
  eq dishT2OccsT(M:Module,tT:Term,cxt:Context,sb:Substitution) =
       'none.Occs [owise] .

*** contexts at dsoup level  [],  non-[] context, '__[CTermList]
  eq dsoupL2OccsT(M:Module,tT:Term,[],sb:Substitution) = 
      dsoupT2OccsT(M:Module,tT:Term,sb:Substitution) .

  eq dsoupL2OccsT(M:Module,tT:Term,
                 '`[_|_`][ctypeT:Term,csoupCxt:Context],sb:Substitution) =
        csoupL2OccsT(M:Module,tT:Term,ctypeT:Term,csoupCxt:Context,
                     sb:Substitution) .

  eq dsoupL2OccsT(M:Module,tT:Term, '__[dsoupCTL:CTermList],sb:Substitution) =
         dsoupL2OccsT(M:Module,tT:Term,getCTLCxt(dsoupCTL:CTermList),
                      sb:Substitution) .

  eq dsoupL2OccsT(M:Module,tT:Term,cxt:Context,sb:Substitution) = 
                  'none.Occs [owise]  .    

*** contexts at csoup level  [], '`{_|_`}[lnT:Term,lsoupT:Term], '__[CTermList]
  eq csoupL2OccsT(M:Module,tT:Term,ctypeT:Term,[], sb:Substitution) =
         csoupT2OccsT(M:Module,ctypeT:Term,tT:Term, sb:Substitution) .
  eq csoupL2OccsT(M:Module,tT:Term,ctypeT:Term,
                  '`{_|_`}[lnT:Term,lsoupCxt:Context], sb:Substitution) =
       lsoupT2OccsT(M:Module,'_`,_[ctypeT:Term,lnT:Term], 
                    tT:Term, sb:Substitution) .
  eq csoupL2OccsT(M:Module,tT:Term,ctypeT:Term, '__[csoupCTL:CTermList],
                  sb:Substitution) =
       csoupL2OccsT(M:Module,tT:Term,ctypeT:Term,getCTLCxt(csoupCTL:CTermList),
                    sb:Substitution) .
  eq csoupL2OccsT(M:Module,tT:Term,ctypeT:Term, cxt:Context,sb:Substitution) = 
       'none.Occs [owise]  .    


*** dsoupT fills hole at dsoup level
*** a cell 
  eq dsoupT2OccsT(M:Module,'`[_|_`][ct:Term,csoupT:Term],sb:Substitution)  =
       csoupT2OccsT(M:Module,ct:Term,csoupT:Term,sb:Substitution) .

*** multiple entities
  eq dsoupT2OccsT(M:Module,'__[dsoupTL:TermList],sb:Substitution)  =
       dsoupArgs2OccsT(M:Module, dsoupTL:TermList,sb:Substitution) .

*** or a thing or (soup variable or unkown)
  eq dsoupT2OccsT(M:Module,dsoupT:Term,sb:Substitution)  =
     (if hasSort(M:Module,dsoupT:Term,'Thing)
      then '<_`,_>[substApp(dsoupT:Term,sb:Substitution),'Out.Loc]
      else 'none.Occs fi)
     [owise] .

*** cdr through termlist at dsoup level
  eq dsoupArgs2OccsT(M:Module,mtTermList,sb:Substitution)  = 'none.Occs .
  eq dsoupArgs2OccsT(M:Module,dsoupT:Term,sb:Substitution)  = 
         dsoupT2OccsT(M:Module,dsoupT:Term,sb:Substitution)  . 

  eq dsoupArgs2OccsT(M:Module,(dsoupT:Term,dstl:TermList),sb:Substitution)  = 
       metaOccsConc(M:Module,
                    dsoupT2OccsT(M:Module,dsoupT:Term,sb:Substitution),  
                    dsoupArgs2OccsT(M:Module, dstl:TermList,sb:Substitution)) .


*** tT:Term fills hole at csoup level, soup var, location, multi elements
  eq csoupT2OccsT(M:Module,ctypeT:Term, '`{_|_`}[lnT:Term,lsoupT:Term],
                  sb:Substitution) =
      lsoupT2OccsT(M:Module,'_`,_[ctypeT:Term,lnT:Term], 
                   lsoupT:Term, sb:Substitution) .

  eq csoupT2OccsT(M:Module,ctypeT:Term, '__[csoupTL:TermList],
                  sb:Substitution) =
       csoupArgs2OccsT(M:Module,ctypeT:Term,csoupTL:TermList,sb:Substitution) .

  eq csoupT2OccsT(M:Module,ctypeT:Term, tT:Term, sb:Substitution) =
       'none.Occs  [owise] .   *** soup var or non conformance


*** cdr through termlist at csoup level
  eq csoupArgs2OccsT(M:Module,ctypeT:Term,mtTermList,sb:Substitution)  =
                     'none.Occs .
  eq csoupArgs2OccsT(M:Module,ctypeT:Term,csoupT:Term,sb:Substitution)  = 
         csoupT2OccsT(M:Module,ctypeT:Term,csoupT:Term,sb:Substitution)  . 
  eq csoupArgs2OccsT(M:Module,ctypeT:Term,(csoupT:Term,csoupTL:TermList),
                     sb:Substitution) = 
       metaOccsConc(M:Module,
                csoupT2OccsT(M:Module,ctypeT:Term,csoupT:Term,sb:Substitution),
                csoupArgs2OccsT(M:Module,ctypeT:Term,csoupTL:TermList,
                                sb:Substitution)) .

*** soup of things or soup vars
  eq lsoupT2OccsT(M:Module,locT:Term, '__[lsoupTL:TermList], sb:Substitution) =
       lsoupArgs2OccsT(M:Module,locT:Term, lsoupTL:TermList, sb:Substitution) .
  eq lsoupT2OccsT(M:Module,locT:Term, lsoupT:Term, sb:Substitution) =
     (if hasSort(M:Module,lsoupT:Term,'Thing)
      then '<_`,_>[substApp(lsoupT:Term,sb:Substitution),
                   substApp(locT:Term,sb:Substitution)]
      else 'none.Occs fi)   *** soup var
     [owise] .


*** cdr through termlist at csoup level
  eq lsoupArgs2OccsT(M:Module,locT:Term,mtTermList,sb:Substitution)  =
                     'none.Occs .
  eq lsoupArgs2OccsT(M:Module,locT:Term,lsoupT:Term,sb:Substitution)  = 
         lsoupT2OccsT(M:Module,locT:Term,lsoupT:Term,sb:Substitution)  . 
  eq lsoupArgs2OccsT(M:Module,locT:Term,(lsoupT:Term,lsoupTL:TermList),
                     sb:Substitution) = 
       metaOccsConc(M:Module,
                lsoupT2OccsT(M:Module,locT:Term,lsoupT:Term,sb:Substitution),
                lsoupArgs2OccsT(M:Module,locT:Term,lsoupTL:TermList,
                                sb:Substitution)) .

endfm